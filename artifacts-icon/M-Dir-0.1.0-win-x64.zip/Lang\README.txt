﻿Language packs
==============
Korean and English are built in. To add a language, put a file named <code>.lng here (for example fr.lng)
and choose it in the Window > Language menu.

The file is UTF-8 text with one line per text: the Korean text, a TAB, the translation.
Use \n for a line break inside a text, and a line starting with # for a comment. Texts that are
missing fall back to English. Start from the English table: every Korean text of the program is
listed in src\MDir\Localization\EnglishStrings.cs.
